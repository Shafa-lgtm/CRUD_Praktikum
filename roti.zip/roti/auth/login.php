<?php

session_start();
include "../config/database.php";

if (isset($_SESSION['username'])) {
    header("Location: ../dashboard/index.php");
    exit;
}

$pesan = "";

if (isset($_POST['login'])) {

    $username = $_POST['username'];
    $password = md5($_POST['password']);

    $query = mysqli_query($conn, "SELECT * FROM users 
    WHERE username='$username' AND password='$password'");

    if (mysqli_num_rows($query) > 0) {

        $data = mysqli_fetch_assoc($query);

        $_SESSION['username'] = $data['username'];

        header("Location: ../dashboard/index.php");
        exit;

    } else {

        $pesan = "Username atau password salah";

    }
}

?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Toko Roti</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>

<body class="login-body">

    <div class="login-box">
        <h1>Toko Roti</h1>
        <p>Silakan login untuk masuk ke dashboard</p>

        <?php if ($pesan != "") { ?>
            <div class="error">
                <?php echo $pesan; ?>
            </div>
        <?php } ?>

        <form method="POST">

            <div class="form-group">
                <label>Username</label>
                <input type="text" name="username" placeholder="Masukkan username" required>
            </div>

            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" placeholder="Masukkan password" required>
            </div>

            <button type="submit" name="login" class="btn-login">
                Login
            </button>
        </form>
    </div>

</body>
</html>