<?php

session_start();

if (!isset($_SESSION['username'])) {
    header("Location: ../auth/login.php");
    exit;
}

include "../config/database.php";

$id = $_GET['id'];

$query = mysqli_query($conn, "SELECT * FROM produk WHERE id='$id'");

$data = mysqli_fetch_assoc($query);

if (!$data) {
    header("Location: index.php");
    exit;
}

if (isset($_POST['update'])) {

    $nama = $_POST['nama'];
    $kategori = $_POST['kategori'];
    $harga = $_POST['harga'];
    $stok = $_POST['stok'];

    mysqli_query($conn, "UPDATE produk SET
        nama='$nama',
        kategori='$kategori',
        harga='$harga',
        stok='$stok'
        WHERE id='$id'
    ");

    header("Location: index.php");
    exit;
}

?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <title>Edit Produk - Toko Roti</title>

    <link rel="stylesheet" href="../assets/css/style.css">

</head>

<body>

<div class="main edit-page">

    <div class="topbar">

        <div>
            <h1>Edit Produk</h1>
            <p>Ubah data produk roti</p>
        </div>

    </div>

    <div class="form-container">

        <form method="POST">

            <div class="form-row">

                <div class="form-group">

                    <label>Nama Roti</label>

                    <input
                        type="text"
                        name="nama"
                        value="<?php echo $data['nama']; ?>"
                        required
                    >

                </div>

                <div class="form-group">

                    <label>Kategori</label>

                    <select name="kategori" required>

                        <option value="Roti Manis"
                            <?php if ($data['kategori'] == "Roti Manis") echo "selected"; ?>>
                            Roti Manis
                        </option>

                        <option value="Croissant"
                            <?php if ($data['kategori'] == "Croissant") echo "selected"; ?>>
                            Croissant
                        </option>

                        <option value="Donat"
                            <?php if ($data['kategori'] == "Donat") echo "selected"; ?>>
                            Donat
                        </option>

                        <option value="Cake"
                            <?php if ($data['kategori'] == "Cake") echo "selected"; ?>>
                            Cake
                        </option>

                        <option value="Pastry"
                            <?php if ($data['kategori'] == "Pastry") echo "selected"; ?>>
                            Pastry
                        </option>

                    </select>

                </div>

            </div>

            <div class="form-row">

                <div class="form-group">

                    <label>Harga</label>

                    <input
                        type="number"
                        name="harga"
                        value="<?php echo $data['harga']; ?>"
                        required
                    >

                </div>

                <div class="form-group">

                    <label>Stok</label>

                    <input
                        type="number"
                        name="stok"
                        value="<?php echo $data['stok']; ?>"
                        required
                    >

                </div>

            </div>

            <div class="form-buttons">

                <a href="index.php" class="btn-cancel">
                    Batal
                </a>

                <button
                    type="submit"
                    name="update"
                    class="btn-save"
                >
                    Update Produk
                </button>

            </div>

        </form>

    </div>

</div>

</body>

</html>