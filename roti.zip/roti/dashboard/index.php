<?php

session_start();

if (!isset($_SESSION['username'])) {
    header("Location: ../auth/login.php");
    exit;
}

include "../config/database.php";

$query = mysqli_query($conn, "SELECT * FROM produk ORDER BY id DESC");

$total_produk = mysqli_num_rows($query);

$stok_query = mysqli_query($conn, "SELECT SUM(stok) AS total FROM produk");
$stok_data = mysqli_fetch_assoc($stok_query);
$total_stok = $stok_data['total'];

if ($total_stok == null) {
    $total_stok = 0;
}

$nilai_query = mysqli_query($conn, "SELECT SUM(harga * stok) AS total FROM produk");
$nilai_data = mysqli_fetch_assoc($nilai_query);
$total_nilai = $nilai_data['total'];

if ($total_nilai == null) {
    $total_nilai = 0;
}

?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <title>Dashboard - Toko Roti</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>

<body>

<div class="sidebar">

    <div class="brand">
        <div>
            <h2>Toko Roti</h2>
            <span>Admin Panel</span>
        </div>
    </div>

    <div class="menu">

        <a href="index.php" class="active">
            Dashboard
        </a>
    </div>

    <div class="sidebar-bottom">

        <div class="admin-name">

            <div class="admin-avatar">
                <?php echo strtoupper(substr($_SESSION['username'], 0, 1)); ?>
            </div>

            <div>
                <strong><?php echo $_SESSION['username']; ?></strong>
                <small>Administrator</small>
            </div>

        </div>

        <a href="../auth/logout.php" class="logout">
            Logout
        </a>

    </div>

</div>

<div class="main">

    <div class="topbar">

        <div>
            <h1>Dashboard</h1>
            <p>Selamat datang, <?php echo $_SESSION['username']; ?> </p>
        </div>

        <div class="date">
            <?php echo date("d M Y"); ?>
        </div>

    </div>

    <div class="cards">
        <div class="card">
            <div>
                <span>Total Produk</span>
                <h2><?php echo $total_produk; ?></h2>
            </div>

        </div>

        <div class="card">
            <div>
                <span>Total Stok</span>
                <h2><?php echo $total_stok; ?></h2>
            </div>
        </div>

        <div class="card">
            <div>
                <span>Nilai Stok</span>
                <h2>
                    Rp <?php echo number_format($total_nilai, 0, ',', '.'); ?>
                </h2>
            </div>

        </div>

    </div>

    <div class="content">

        <div class="content-header">

            <div>
                <h2>Data Produk Roti</h2>
                <p>Daftar produk yang tersedia</p>
            </div>

            <a href="tambah.php" class="btn-add">
                + Tambah Produk
            </a>

        </div>

        <div class="table-container">

            <table>

                <thead>

                    <tr>
                        <th>No</th>
                        <th>Nama Roti</th>
                        <th>Kategori</th>
                        <th>Harga</th>
                        <th>Stok</th>
                        <th>Aksi</th>
                    </tr>

                </thead>

                <tbody>

                <?php

                $no = 1;

                if (mysqli_num_rows($query) > 0) {

                    while ($produk = mysqli_fetch_assoc($query)) {

                ?>

                    <tr>

                        <td>
                            <?php echo $no++; ?>
                        </td>

                        <td>
                            <strong>
                                <?php echo $produk['nama']; ?>
                            </strong>
                        </td>

                        <td>
                            <span class="category">
                                <?php echo $produk['kategori']; ?>
                            </span>
                        </td>

                        <td>
                            Rp <?php echo number_format($produk['harga'], 0, ',', '.'); ?>
                        </td>

                        <td>

                            <?php if ($produk['stok'] <= 5) { ?>

                                <span class="stock-low">
                                    <?php echo $produk['stok']; ?>
                                </span>

                            <?php } else { ?>

                                <span class="stock">
                                    <?php echo $produk['stok']; ?>
                                </span>

                            <?php } ?>

                        </td>

                        <td>

                            <div class="actions">

                                <a
                                    href="edit.php?id=<?php echo $produk['id']; ?>"
                                    class="btn-edit"
                                >
                                    Edit
                                </a>

                                <a
                                    href="hapus.php?id=<?php echo $produk['id']; ?>"
                                    class="btn-delete"
                                    onclick="return confirm('Yakin ingin menghapus produk ini?')"
                                >
                                    Hapus
                                </a>

                            </div>

                        </td>

                    </tr>

                <?php

                    }

                } else {

                ?>

                    <tr>
                        <td colspan="6" class="empty">
                            Belum ada produk.
                        </td>
                    </tr>

                <?php } ?>

                </tbody>

            </table>

        </div>

    </div>

</div>

</body>

</html>