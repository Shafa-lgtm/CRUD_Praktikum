<?php

session_start();

if (!isset($_SESSION['username'])) {
    header("Location: ../auth/login.php");
    exit;
}

include "../config/database.php";

$id = $_GET['id'];

mysqli_query($conn, "DELETE FROM produk WHERE id='$id'");

header("Location: index.php");
exit;

?>