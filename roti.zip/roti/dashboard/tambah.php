<?php

session_start();

if (!isset($_SESSION['username'])) {
    header("Location: ../auth/login.php");
    exit;
}

include "../config/database.php";

if (isset($_POST['simpan'])) {

    $nama = $_POST['nama'];
    $kategori = $_POST['kategori'];
    $harga = $_POST['harga'];
    $stok = $_POST['stok'];

    mysqli_query($conn, "INSERT INTO produk 
    (nama, kategori, harga, stok)
    VALUES
    ('$nama', '$kategori', '$harga', '$stok')");

    header("Location: index.php");
    exit;
}

?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <title>Tambah Produk - Toko Roti</title>

    <link rel="stylesheet" href="../assets/css/style.css">

</head>

<body>

<div class="sidebar">

    <div class="brand">

        <div class="brand-icon">
            🍞
        </div>

        <div>
            <h2>Toko Roti</h2>
            <span>Admin Panel</span>
        </div>

    </div>

    <div class="menu">

        <a href="index.php">
            🏠 Dashboard
        </a>

        <a href="tambah.php" class="active">
            🥐 Tambah Produk
        </a>

    </div>

    <div class="sidebar-bottom">

        <div class="admin-name">

            <div class="admin-avatar">
                <?php echo strtoupper(substr($_SESSION['username'], 0, 1)); ?>
            </div>

            <div>
                <strong><?php echo $_SESSION['username']; ?></strong>
                <small>Administrator</small>
            </div>

        </div>

        <a href="../auth/logout.php" class="logout">
            Logout
        </a>

    </div>

</div>

<div class="main">

    <div class="topbar">

        <div>
            <h1>Tambah Produk</h1>
            <p>Tambahkan produk roti baru</p>
        </div>

    </div>

    <div class="form-container">

        <div class="form-header">

            <div>
                <h2>Form Produk</h2>
                <p>Masukkan data produk roti</p>
            </div>

        </div>

        <form method="POST">

            <div class="form-row">

                <div class="form-group">

                    <label>Nama Roti</label>

                    <input
                        type="text"
                        name="nama"
                        placeholder="Contoh: Roti Coklat"
                        required
                    >

                </div>

                <div class="form-group">

                    <label>Kategori</label>

                    <select name="kategori" required>

                        <option value="">
                            Pilih kategori
                        </option>

                        <option value="Roti Manis">
                            Roti Manis
                        </option>

                        <option value="Croissant">
                            Croissant
                        </option>

                        <option value="Donat">
                            Donat
                        </option>

                        <option value="Cake">
                            Cake
                        </option>

                        <option value="Pastry">
                            Pastry
                        </option>

                    </select>

                </div>

            </div>

            <div class="form-row">

                <div class="form-group">

                    <label>Harga</label>

                    <input
                        type="number"
                        name="harga"
                        placeholder="Contoh: 15000"
                        required
                    >

                </div>

                <div class="form-group">

                    <label>Stok</label>

                    <input
                        type="number"
                        name="stok"
                        placeholder="Contoh: 20"
                        required
                    >

                </div>

            </div>

            <div class="form-buttons">

                <a href="index.php" class="btn-cancel">
                    Kembali
                </a>

                <button
                    type="submit"
                    name="simpan"
                    class="btn-save"
                >
                    Simpan Produk
                </button>

            </div>

        </form>

    </div>

</div>

</body>

</html>