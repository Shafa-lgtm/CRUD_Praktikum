const form = document.querySelector("form");

if (form) {
    form.addEventListener("submit", function () {

        const username = document.querySelector("input[name='username']").value;
        const password = document.querySelector("input[name='password']").value;

        if (username == "" || password == "") {
            alert("Username dan password harus diisi");
        }

    });
}