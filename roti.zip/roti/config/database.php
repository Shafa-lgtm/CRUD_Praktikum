<?php

$host = "localhost";
$user = "root";
$password = "shafa";
$database = "toko_roti";

$conn = mysqli_connect($host, $user, $password);

if (!$conn) {
    die("Koneksi gagal");
}

mysqli_query($conn, "CREATE DATABASE IF NOT EXISTS toko_roti");

$conn = mysqli_connect($host, $user, $password, $database);

if (!$conn) {
    die("Koneksi database gagal");
}

mysqli_query($conn, "CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL,
    password VARCHAR(255) NOT NULL
)");

mysqli_query($conn, "CREATE TABLE IF NOT EXISTS produk (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama VARCHAR(100) NOT NULL,
    kategori VARCHAR(50) NOT NULL,
    harga INT NOT NULL,
    stok INT NOT NULL
)");

$cek_user = mysqli_query($conn, "SELECT * FROM users");

if (mysqli_num_rows($cek_user) == 0) {
    $password_admin = md5("admin123");

    mysqli_query($conn, "INSERT INTO users (username, password) 
    VALUES ('admin', '$password_admin')");
}
?>